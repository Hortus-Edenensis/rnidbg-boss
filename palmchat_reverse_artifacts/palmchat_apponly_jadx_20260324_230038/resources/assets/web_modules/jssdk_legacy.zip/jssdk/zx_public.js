if (zx == undefined) {
    var zx = {};
}

zx.public = {

    // 获取设备信息
    getDeviceInfo: function (resultCallback) {
        cordova.exec(function (result) {
                if (resultCallback != null) {
                    resultCallback(result);
                }
            },
            function (error) {
                if (resultCallback != null) {
                    resultCallback(null);
                }
            }, "PublicUtils", "getDeviceInfo", []);
    },
    // 获取广告信息
    getUserInfoForAds: function (resultCallback) {
        cordova.exec(function (result) {
                if (resultCallback != null) {
                    resultCallback(result);
                }
            },
            function (error) {
                if (resultCallback != null) {
                    resultCallback(null);
                }
            }, "PublicUtils", "getUserInfoForAds", []);
    },
    //打开app，并跳到指定页面
    openApp: function (packageName, pageUrl) {
        cordova.exec(null, null, "PublicUtils", "openApp", [packageName, pageUrl]);
    },

    //判断app是否安装
    isAppInstalled: function (packageName, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "PublicUtils", "isAppInstalled", [packageName]);
    },
};