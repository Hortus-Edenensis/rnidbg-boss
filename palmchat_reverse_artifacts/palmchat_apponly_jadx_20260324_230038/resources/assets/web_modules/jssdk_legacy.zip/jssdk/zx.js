var zx = {
    /**
     * 通过component启动activity
     * @param packageName 包名字符串
     * @param className 类名字符串
     * @param bundle 需要传递的数据，类型为json，可以为null, 目前不支持数组和json嵌套
     */
    startActivityByComponent: function (packageName, className, bundle) {
        cordova.exec(null, null, "StartActivity", "startActivityByComponent", [packageName, className, bundle]);
    },

    /**
     * 通过action启动activity
     * @param action 字符串
     * @param bundle 需要传递的数据，类型为json, 可以为null, 目前不支持数组和json嵌套
     */
    startActivityByAction: function (action, bundle) {
        cordova.exec(null, null, "StartActivity", "startActivityByAction", [action, bundle]);
    },

    /**
     * 启动权限引导界面
     */
    startBootGuideActivity: function () {
        cordova.exec(null, null, "StartActivity", "startBootGuideActivity", []);
    },

    /**
     * 获取掌信当前登录用户的uid
     * @param resultCallback 结果回掉函数，通过参数返回uid，类型为string
     */
    getUid: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUid", []);
    },

    /**
     * 获取掌信getReportInfo
     * @param resultCallback 结果回掉函数，通过参数返回reportInfo，类型为json
     */
    getReportInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "reportInfo", "getReportInfo", []);
    },

    /**
     *  返回
     */
    closeWindow: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "reportInfo", "closeWindow", []);
    },

    /**
     * 获取聊天记录getChatInfo
     * @param resultCallback 结果回掉函数，通过参数返回reportInfo，类型为array
     */
    getChatInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "reportInfo", "getChatInfo", []);
    },

    /**
     * addToBlackList加入黑名单,uid从native界面传入
     */
    addToBlackList: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "reportInfo", "addToBlackList", []);
    },

    //addToBlackList加入黑名单,uid由js传入
    addToBlackListWithUid: function (key, resultCallback) {
            cordova.exec(function (result) {
                if (resultCallback != null) {
                    resultCallback(result);
                }
            }, function (error) {
                if (resultCallback != null) {
                    resultCallback(null);
                }
            }, "reportInfo", "addToBlackListWithUid", [key]);
     },

    /**
     * 获取连信UserInfo
     */
    getUserInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserInfo", []);
    },

    /**
     * 获取连信红包相关UserInfo
     */
    getUserInfoForPay: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserInfoForPay", []);
    },

    /**
     * 获取数字联盟id
     */
    getSzlmId: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getSzlmId", []);
    },

    /**
     * 获取连信广告相关UserInfo
     */
    getUserInfoForAds: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserInfoForAds", []);
    },

    //获取太极key
    getTaiChiInfo: function (key, resultCallback) {
            cordova.exec(function (result) {
                if (resultCallback != null) {
                    resultCallback(result);
                }
            }, function (error) {
                if (resultCallback != null) {
                    resultCallback(null);
                }
            }, "UserInfo", "getTaiChiInfo", [key]);
     },
    /**
     *  小秘书推荐成功页，点击按钮跳转附近的人
     */
    jumpToNearbyPeople: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "jumpToNearbyPeople", []);
    },

    /**
     *  小一键长期推送使用，点击按钮跳转附近的人: fromtype=8 从小一键发送结果页, fromtype=9 从小一键过期页
     */
    jumpToNearbyPeopleNew: function (fromType, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "jumpToNearbyPeopleNew", [fromType]);
    },

    /**
     *  小秘书推荐成功页，点击按钮跳漂流瓶
     */
    jumpToBottle: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "jumpToBottle", []);
    },

    addFriendAlert: function (uid, sourceType, sourceSubType) {
        cordova.exec(null, null, "NetworkRequest", "addFriendAlert", [uid, sourceType, sourceSubType]);
    },

    /**
     * 获取掌信UserAgent
     * @param resultCallback 结果回掉函数，通过参数返回UserAgent，类型为json
     */
    getUserAgent: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserAgent", []);
    },

    /**
     * 获取用户头像昵称
     * @param resultCallback 结果回掉函数，通过参数返回profile，类型为json
     */
    getUserProfile: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserProfile", []);
    },

    /**
     * 用户是否关闭通讯录权限
     */
    isContactClose: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "isContactClose", []);
    },

    /**
     * 上传通讯录
     */
    uploadContact: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "uploadContact", []);
    },

    /**
      * 上传通讯录(支持动态权限请求0 成功，-1 失败，-2权限被拒绝)
     */
    uploadContactExt: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "uploadContactExt", []);
    },

    /**
     * 调起系统短信
     */
    callMessage: function (info) {
        cordova.exec(null, null, "RedPacketPullNewUtils", "callMessage", [info]);
    },
    /**
     * 调起系统短信，发送成功后回调
     */
    callMessageV2: function (info, resultCallback) {
        cordova.exec(function (result) {
             if (resultCallback != null) {
                 resultCallback(result);
             }
         }, function (error) {
             if (resultCallback != null) {
                 resultCallback(null);
             }
         }, "RedPacketPullNewUtils", "callMessageV2", [info]);
    },
    /**
     * 根据传入参数生成图片（红包拉新专用）
     */
    createImg: function (info, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "createImg", [info]);
    },

    /**
     * 判断app是否安装
     */
    isAppInstalled: function (info, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "isAppInstalled", [info]);
    },

    /**
     * 打开第三方app
     */
    startApp: function (info, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "startApp", [info]);
    },

    /**
     * 打开分享界面分享链接
    */
    shareLink: function (title, description, linkUrl, iconUrl) {
        cordova.exec(null, null, "StartActivity", "shareLink", [title, description, linkUrl, iconUrl]);
    },

    /**
      * 分享链接消息到朋友圈
     */
    shareWebLinkToMoments: function (title,iconUrl,linkUrl,resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "ShareUtils", "shareWebLinkToMoments", [title,iconUrl,linkUrl]);
    },

    /**
     * 打开app，并跳到指定页面
     */
    openApp: function (packageName, pageUrl) {
        cordova.exec(null, null, "RedPacketPullNewUtils", "openApp", [packageName, pageUrl]);
    },


    /**
     * 跳转新手引导页面
     */
    jumpToGuide: function (missionId, itemData, resultCallback) {
        cordova.exec(function (result) {
                    if (resultCallback != null) {
                        resultCallback(true);
                    }
                }, function (error) {
                    if (resultCallback != null) {
                        resultCallback(false);
                    }
                }, "StartActivity", "jumpToGuide", [missionId, itemData]);
    },

    jumpToSquarePublish: function (from, resultCallback) {
        cordova.exec(function (result) {
                    if (resultCallback != null) {
                        resultCallback(true);
                    }
                }, function (error) {
                    if (resultCallback != null) {
                        resultCallback(false);
                    }
                }, "StartActivity", "jumpToSquarePublish", [from]);
    },

    /**
     * 下载app
     */
    downloadApp: function (packageName, downloadUrl) {
        cordova.exec(null, null, "RedPacketPullNewUtils", "downloadApp", [packageName, downloadUrl]);
    },

    /**
     * 客户端是否已经上传过通讯录
     */
    isContactUploaded: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "isContactUploaded", []);
    },

    /**
     *  通付盾，滑块验证，获取Info
     */
    getValidateInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "getValidateInfo", []);
    },

    /**
     * 下载app
     */
    showWallet: function () {
        cordova.exec(null, null, "RedPacketPullNewUtils", "showWallet", []);
    },

    /**
     * 打开内置钱包
     */
    openWallet: function () {
        cordova.exec(null, null, "RedPacketPullNewUtils", "openWallet", []);
    },

    /**
     *  通付盾，滑块验证，获取Sceneid
     */
    getSceneid: function (id, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "slideVerify", "getSceneid", [id]);
    },

    /**
     *  通付盾，滑块验证，滑动成功
     */
    sliderResponse: function (sceneId, result, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "slideVerify", "sliderResponse", [sceneId, result]);
    },

    /**
     *  保存截图
     */
    screenshot: function (top, bottom, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "screenshot", [top, bottom]);
    },

    /**
     *  保存图片url
     */
    saveImage: function (url, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "saveImage", [url]);
    },

    /**
     *  跳转到聊天页面
     */
    jumpToChat: function (uid, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "jumpToChat", [uid]);
    },

    /**
     * 获取连信DeviceInfo
     */

    getDeviceInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getDeviceInfo", []);
    },

    /**
     * 获取连信Token
     */

    getToken: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getToken", []);
    },

    /**
     *  跳转到cordovaActivity
     */
    jumpToCordova: function (url, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "StartActivity", "jumpToCordova", [url]);
    },

    /**
     * 关闭当前webview，并重新加载掌中宝首页
     */
    closeWebView: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "closeWebView", []);
    },

    /**
     * 关闭当前webview，重新加载新的地址
     */
    reloadWebView: function (url, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "reloadWebView", [url]);
    },

    /** 加载错误页面
     */
    loadErrorView: function (params, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "loadErrorView", [params]);
    },

    /**
     *  是否显示免费发红包的角标
     */
    setBonusUnreadBadge: function (count, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "setBonusUnreadBadge", [count]);
    },

    /**
     * 获取屏幕宽高
     */
    getScreen: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "AdBanner", "getScreen", []);
    },

    /**
     * 设置webview 高度
     */
    setWebViewHeight: function (height) {
        cordova.exec(null, null, "AdBanner", "setWebViewHeight", [height]);
    },

    /**
     * banner跳转url
     */
    actionUrl: function (url) {
        cordova.exec(null, null, "AdBanner", "actionUrl", [url]);
    },

    /**
     * 支付
     */
    startSdpPay: function (params, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(error);
            }
        }, "SdpUtil", "startSdpPay", [params]);
    },

    sdpGetOcr: function (params, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(error);
            }
        }, "SdpUtil", "sdpGetOcr", [params]);
    },
    /**
    * 活体检测
    */
    sdpDetectionLive: function (params, resultCallback) {
        cordova.exec(function (result) {
                if (resultCallback != null) {
                    resultCallback(result);
                }
            }, function (error) {
                if (resultCallback != null) {
                    resultCallback(error);
                }
            }, "SdpUtil", "sdpDetectionLive", [params]);
        },
        /**
         * 活体检测+身份证校验检测
         */
         sdpDetectionLiveAndAuth: function (params, resultCallback) {
             cordova.exec(function (result) {
                     if (resultCallback != null) {
                         resultCallback(result);
                     }
                 }, function (error) {
                     if (resultCallback != null) {
                         resultCallback(error);
                     }
                 }, "SdpUtil", "sdpDetectionLiveAndAuth", [params]);
             },
        /**
         * 退出钱包
         */
         sdpExitWallet: function ( resultCallback) {
             cordova.exec(function (result) {
                     if (resultCallback != null) {
                         resultCallback(result);
                     }
                 }, function (error) {
                     if (resultCallback != null) {
                         resultCallback(error);
                     }
                 }, "SdpUtil", "sdpExitWallet",[]);
             },

    /**
     * 通知webview，当前url错误or违规
     */
    notifyWebViewError: function (url, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "reportInfo", "notifyWebViewError", [url]);
    },

    /**
     * 通讯录选择发短信
     */
    showContactSelectView: function (isSend, content, title1, title2, extra, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "showContactSelectView", [isSend, content, title1, title2, extra]);
    },

    /**
     * 跳转到首页"我的"tab并关闭当前H5页面
     */
    jumpToSettingTab: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "jumpToSettingTab", []);
    },

    /**
     * 手拉手领现金气泡入口
     */
    dismissHandInHandBubble: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacketPullNewUtils", "dismissHandInHandBubble", []);
    },

    /**
     * 网络请求本地Api
     * callback
     * url 全路径url
     * method 整型 GET = 0;  POST = 1;
     * bundle requestbody JSON
     **/
    requestLocalApi: function (resultCallback, url, method, bundle) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "requestLocalApi", [url, method, bundle]);
    },

     /**
     * 网络请求本地Api（使用app server 环境）
     * callback
     * url 相对路径url ，如"/user/v3/update.json"
     * method 整型 GET = 0;  POST = 1;
     * bundle requestbody JSON
     **/
    requestLocalApiWithLxServer: function (resultCallback, url, method, bundle) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "requestLocalApiWithLxServer", [url, method, bundle]);
    },

    /**
     * 显示系统toast
     * text: 要在toast中显示的字符串
     * duration: 0：短时间显示，1：长时间显示
     * position: 0: 屏幕下方, 1: 屏幕中间, 2: 屏幕上方
     **/
    showToast: function (text, duration, position) {
        cordova.exec(null, null, "LocalApi", "showToast", [text, duration, position]);
    },

     //增值vip支付
     vipPay: function(menuType, scene, platform, orderInfo, resultCallback) {
        cordova.exec(function (result) {
           if (resultCallback != null) {
               resultCallback(result);
           }
        }, function (error) {
           if (resultCallback != null) {
               resultCallback(null);
           }
        }, "LxVip", "vipPay", [menuType, scene, platform, orderInfo]);
     },

      //打开增值一期支付页面
      showPaymentPage: function (url, resultCallback) {
         console.log("showPaymentPage");
         cordova.exec(function (result) {
             if (resultCallback != null) {
                 resultCallback(result);
             }
         }, function (error) {
             if (resultCallback != null) {
                 resultCallback(null);
             }
         }, "LxVip", "showPaymentPage", [url]);
          },

      wkLog: function (uid, component, result, extra) {
        cordova.exec(null, null, "Log", "wkLog", [uid, component, result, extra]);
      },

      //feed打卡成功
      markFeedSuccess: function(params, resultCallback) {
        window.cordova.exec(function(result) {
            if (resultCallback != null) {
                resultCallback(result)
            }
        },
            function(error) {
                console.log(error)
             if (resultCallback != null) {
                 resultCallback(null)
             }
        }, 'General', 'markFeedSuccess', [params])
      },

      //
      execAction: function(action, params, resultCallback) {
      window.cordova.exec(function(result) {
      if (resultCallback != null) {
      resultCallback(result)
      }
      },
      function(error) {
      console.log(error)
      if (resultCallback != null) {
      resultCallback(error)
      }
      },
      'General', action, [params])
      },
};