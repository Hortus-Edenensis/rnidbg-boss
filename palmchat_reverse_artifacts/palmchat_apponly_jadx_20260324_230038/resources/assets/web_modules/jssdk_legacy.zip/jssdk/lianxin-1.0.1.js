/*
* 调用方法：
*
例子1：
lx.checkJsApi(['chooseImage','chooseImage2'],function(res){});
例子2：
lx.getLocation({a:1,b:2},function(res){});
例子3：
为了确保内置对象已经加载完毕，建议ready里初始化加载。
wx.ready(function(){
//...
});
*
* */
(function() {
    var lx = {
        error: function() {},
        ready: function(success, fail) {
            if (window["cordova"]) {
                typeof success === "function" && success();
            } else {
                setTimeout(function() {
                    if (window["cordova"]) {
                        typeof success === "function" && success();
                    } else {
                        typeof fail === "function" &&
                            fail({
                            msg: "请在指定的客户端下访问"
                        });
                    }
                }, 200);
            }
        },
        lxExce: function(plugin, action, params, resultCallback) {
            if (window["cordova"]) {
                window.cordova.exec(function(result) {
                    console.log("result:" + result);
                    if (typeof resultCallback === "function") {
                        resultCallback(result);
                    }
                }, function(error) {
                    console.log("error:" + error);
                    if (typeof resultCallback === "function") {
                        resultCallback(error);
                    }
                },
                    plugin,
                    action,
                    params);
            } else {
                console.log("cordova 未加载");
            }
        },
        config: function(grantInfo, success) {
            this.lxExce("GrantApp", "grantApp", grantInfo, success);
        },
        checkJsApi: function(jsApiList = [], resultCallback) {
            var grantInfo = jsApiList.map((v, k) => "lx_" + v);
            //console.log("转换后的方法：", grantInfo);
            //resultCallback(grantInfo);
            this.lxExce("GrantApp", "lx_checkJsApi", grantInfo, resultCallback);
        },
        getLocation: function(args, resultCallback) {
            this.lxExce("LxLocation", "lx_getLocation", args, resultCallback);
        },
        selectLocation: function(args, resultCallback) {
            this.lxExce("LxLocation", "lx_selectLocation", args, resultCallback);
        },
        showLocation: function(args, resultCallback) {
            this.lxExce("LxLocation", "lx_showLocation", args, resultCallback);
        },
        getUserAgent: function(resultCallback) {
            this.lxExce("LxComm", "lx_getUserAgent", "", resultCallback);
        },
        getDeviceInfo: function(resultCallback) {
            this.lxExce("LxComm", "lx_getDeviceInfo", "", resultCallback);
        },
        closeWebView: function(resultCallback) {
            this.lxExce("LxComm", "lx_closeWebView", "", resultCallback);
        },
        checkNativeApp: function (args, resultCallback) {
            this.lxExce("LxComm", "lx_checkNativeApp", args, resultCallback);
        },
        openNativeApp: function (args, resultCallback) {
            this.lxExce("LxComm", "lx_openNativeApp", args, resultCallback);
        },
        reportEvent: function (args, resultCallback) {
            this.lxExce("LxComm", "lx_reportEvent", args, resultCallback);
        },
        reportEventExtra: function (args, resultCallback) {
            this.lxExce("LxComm", "lx_reportEventExtra", args, resultCallback);
        },
        getPaySupportPlatform: function(resultCallback) {
            this.lxExce("LxPay", "lx_getPaySupportPlatform", [], resultCallback);
        },
        pay: function(scene, platform, orderInfo, resultCallback) {
            this.lxExce(
                "LxPay",
                "lx_pay", [platform, orderInfo, scene],
                resultCallback);
        },
        shareText: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareText", args, resultCallback);
        },
        shareWeb: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareWeb", args, resultCallback);
        },
        shareImage: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareImage", args, resultCallback);
        },
        shareSVideo: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareSVideo", args, resultCallback);
        },
        shareNameCard: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareNameCard", args, resultCallback);
        },
        shareApp: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareApp", args, resultCallback);
        },
        shareWebApp: function(args, resultCallback) {
            this.lxExce("LxShare", "lx_shareWebApp", args, resultCallback);
        },
        getPrivDeviceInfo: function(args, resultCallback) {
            this.lxExce("LxComm", "lx_getPrivDeviceInfo", args, resultCallback);
        },
        getDeviceId: function(resultCallback) {
            this.lxExce("LxComm", "lx_getDeviceId", "", resultCallback);
        },
        getWebViewSize: function(resultCallback) {
            this.lxExce("LxComm", "lx_getWebViewSize", "", resultCallback);
        },
        login: function(args,resultCallback) {
            this.lxExce("LxLogin", "lx_login", args, resultCallback);
        },
    };
    window["lx"] = lx;
})();