/**
 * 获取经纬度
 * resultCallback = function(result) {}
 * result的数据结构为{"latitude":0, "longitude":0, "address": "xxxx", "name": "yyyy"}
 */
zx.getLocation = function (resultCallback) {
    cordova.exec(function (result) {
        if (resultCallback != null) {
            resultCallback(result);
        }
    }, function (error) {
        if (resultCallback != null) {
            resultCallback(null);
        }
    }, "Location", "getLocation", []);
};

/**
 * 启动位置选择界面，返回选择的位置信息
 * enableMapDrag: 是否允许拖动地图来选择位置, true：允许，false:  不允许
 * poiSearchRadius: POI的搜索半径，单位米
 * resultCallback = function(result) {}
 * result的数据结构为{"latitude":0, "longitude":0, "address": "xxxx", "name": "yyyy"}
 */
zx.selectLocation = function (enableMapDrag, poiSearchRadius, resultCallback) {
    cordova.exec(function (result) {
        if (resultCallback != null) {
            resultCallback(result);
        }
    }, function (error) {
        if (resultCallback != null) {
            resultCallback(null);
        }
    }, "Location", "selectLocation", [enableMapDrag, poiSearchRadius]);
};

/**
 * 启动位置显示界面
 * location: json对象，结构为{"latitude":0, "longitude":0, "address": "xxxx", "name": "yyyy"}
 * 其中latitude和longitude是必填的，address和name是可选的
 */
zx.showLocation = function(location) {
    cordova.exec(null, null, "Location", "showLocation", [location]);
};