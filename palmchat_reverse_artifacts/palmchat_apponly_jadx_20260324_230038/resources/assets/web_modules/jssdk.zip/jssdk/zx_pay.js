/**
 * 启动聚合支付
 * @param platform 用户所选择支付平台：alipay, wechat, shengpay
 * @param orderInfo 支付请求参数字符串，主要包含商户的订单信息，key=value形式，以&连接
 * @param resultCallback 支付结果回调 resultCallback = function(code, msg)
 */
zx.pay = function (platform, orderInfo, resultCallback) {
    cordova.exec(function (result) {
        if (resultCallback != null) {
            resultCallback(result.code, result.msg, result.extra);
        }
    }, function (error) {
        if (resultCallback != null) {
            resultCallback(-9999, error);
        }
    }, "Pay", "pay", [platform, orderInfo]);
};

zx.lxpay = function (platform, orderInfo, resultCallback) {
    cordova.exec(function (result) {
        if (resultCallback != null) {
            resultCallback(result.code, result.msg, result.extra);
        }
    }, function (error) {
        if (resultCallback != null) {
            resultCallback(-9999, error);
        }
    }, "Pay", "lxpay", [platform, orderInfo]);
};