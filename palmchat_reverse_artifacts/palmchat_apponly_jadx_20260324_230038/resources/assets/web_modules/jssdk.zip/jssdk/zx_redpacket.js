/**
 * 启动实名认证
 * successCallback: 认证成功的回调函数，successCallback = function() {}
 * failedCallback: 认证失败的回调函数, failedCallback = function(code, msg) {}
 */
zx.startRealNameVerification = function (successCallback, failedCallback) {
    cordova.exec(function (result) {
        if (successCallback != null) {
            successCallback();
        }
    }, function (error) {
        if (failedCallback != null) {
            failedCallback(error.code, error.msg);
        }
    }, "RedPacket", "startRealNameVerification", []);
};
    /**
     * 打开内置钱包
     */
    zx.openWallet = function () {
        cordova.exec(null, null, "RedPacket", "openWallet", []);
    };
    /**
      * 上传通讯录(支持动态权限请求0 成功，-1 失败，-2权限被拒绝)
     */
    zx.uploadContactExt = function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacket", "uploadContactExt", []);
    };

    /**
     * 用户是否关闭通讯录权限
     */
    zx.isContactClose= function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "RedPacket", "isContactClose", []);
    };