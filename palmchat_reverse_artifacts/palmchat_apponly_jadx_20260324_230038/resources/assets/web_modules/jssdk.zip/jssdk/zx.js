function strEndsWith(str, suffix) {
    return str.match(suffix + "$") == suffix;
}

function loadJavascript(path) {
    var scriptElements = document.getElementsByTagName("script");
    for (index in scriptElements) {
        if (scriptElements[index].src !== undefined && strEndsWith(scriptElements[index].src, path)) {
            console.log("duplicate file : " + scriptElements[index].src + " : " + path);
            return;
        }
    }

    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = path;
    document.getElementsByTagName("head")[0].appendChild(script);
}

loadJavascript('/zx_local_res/jssdk/html2canvas.js');
loadJavascript('/zx_local_res/jssdk/cordova.js');
loadJavascript('/zx_local_res/jssdk/zx_location.js');
loadJavascript('/zx_local_res/jssdk/zx_redpacket.js');
loadJavascript('/zx_local_res/jssdk/zx_miniprogram.js');
loadJavascript('/zx_local_res/jssdk/zx_pay.js');

var zx = {
    /**
     * 获取掌信当前登录用户的uid
     * @param resultCallback 结果回掉函数，通过参数返回uid，类型为string
     */
    getUid: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUid", []);
    },

    /**
     * 获取掌信UserAgent
     * @param resultCallback 结果回掉函数，通过参数返回UserAgent，类型为json
     */
    getUserAgent: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserAgent", []);
    },

    /**
     * 获取用户头像昵称
     * @param resultCallback 结果回掉函数，通过参数返回profile，类型为json
     */
    getUserProfile: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getUserProfile", []);
    },

    /**
     *  通付盾，滑块验证，获取Info
     */
    getValidateInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "UserInfo", "getValidateInfo", []);
    },

    /**
     * 完善资料完成
     */
    mendFinished: function () {
        cordova.exec(null, null, "UserInfo", "mendFinished", []);
    },

    /**
     * web平台分享
     * bundle 为json对象
     *      key:urlExtra 表示需要拼接在小程序Url后面的参数
     *      key:titleInfo 小程序分享时设置的气泡标题
     */
    share: function (type, bundle, base64data) {
        cordova.exec(null, null, "webPlatform", "share", [type, bundle, base64data]);
    },

    shareWithImage: function (base64data) {
        cordova.exec(null, null, "webPlatform", "share", [0, null, base64data]);
    },

    captureScreenAndShare: function (domElement) {
        var zxObj = this;
        html2canvas(domElement, {
            allowTaint: true
        }).then(function (canvas) {
            var data = canvas.toDataURL();
            zxObj.shareWithImage(data.substring(data.indexOf(",") + 1));
        });
    },

    /**
     * 跳转到CordovaWebActivity
    */
    jumpToCordova: function (url) {
        cordova.exec(null, null, "webPlatform", "jumpToCordova", [url]);
    },

    /**
     *  跳转到cordovaActivity
     */
    jumpToCordova2: function (url,showMenu, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "jumpToCordova2", [url,showMenu]);
    },
    /**
     * 调起系统短信
     */
    callMessage: function (info) {
        cordova.exec(null, null, "webPlatform", "callMessage", [info]);
    },
    /**
     * 调起系统短信，发送成功后回调
     */
    callMessageV2: function (info, resultCallback) {
        cordova.exec(function (result) {
             if (resultCallback != null) {
                 resultCallback(result);
             }
         }, function (error) {
             if (resultCallback != null) {
                 resultCallback(null);
             }
         }, "webPlatform", "callMessageV2", [info]);
    },
    /**
     * 设置状态栏颜色
     */
    setStatusBarColor: function (color) {
        cordova.exec(null, null, "webPlatform", "setStatusBarColor", [color]);
    },
    /**
     *  保存图片url
     */
    saveImage: function (url, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "saveImage", [url]);
    },

   syncAll: function(resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "syncAll", []);
    },

    /**
     * 返回
     */
    closeWindow: function () {
        cordova.exec(null, null, "webPlatform", "closeWindow", []);
    },

    closeWindowWithResultCode: function (resultCode) {
        cordova.exec(null, null, "webPlatform", "closeWindowWithResultCode", [resultCode]);
    },

    requestLocalApi: function (resultCallback, url, method, bundle) {
        console.log("requestLocalApi");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "requestLocalApi", [url, method, bundle]);
    },

    requestLocalApiWithLxServer: function (resultCallback, url, method, bundle) {
        console.log("requestLocalApiWithLxServer");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "requestLocalApiWithLxServer", [url, method, bundle]);
    },

    requestLocalApiWithLxServerBeforeLogin: function (resultCallback, url, uid, sessionId, method, bundle) {
        console.log("requestLocalApiWithLxServerBeforeLogin");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "requestLocalApiWithLxServerBeforeLogin", [url, uid, sessionId, method, bundle]);
    },

    uploadPortrait: function (resultCallback, url, fileUrl, name) {
        console.log("uploadPortrait");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "uploadPortrait", [url, fileUrl, name]);
    },

    uploadPortraitBeforeLogin: function (resultCallback, url, uid, sessionId, fileUrl, name) {
        console.log("uploadPortraitBeforeLogin");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LocalApi", "uploadPortraitBeforeLogin", [url, uid, sessionId, fileUrl, name]);
    },

    addExpression: function (resultCallback, url) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "Expression", "addExpression", [url]);
    },

    /*
    int type = args.getInt(0);
    String tag = args.getString(1);
    String msg = args.getString(2);
    //LOG_FLAG_NORMAL = 0; //普通log
    //LOG_FLAG_FILE =  1<<0; //会保存到文件中，但不会上传
    //LOG_FLAG_STATS = 1<<1; //会根据服务器配置（实时上传，离线上传，或者不上传）
    int flag = args.getInt(3);
    */
    commonLog: function (type, tag, msg, flag) {
        cordova.exec(null, null, "Log", "commonLog", [type, tag, msg, flag]);
    },

    /*
    int type
    String uid        //user id
    String component  //component code define in userAction.java
    String userAction //user action
    String result     //action result
    String extra      //json extra
    */

    actionLog: function (type, uid, component, userAction, result, extra) {
        cordova.exec(null, null, "Log", "actionLog", [type, uid, component, userAction, result, extra]);
    },

    /*
    String uid        //user id
    String component  //component code define in userAction.java
    String result     //action result
    String extra      //json extra
    */
    wkLog: function (uid, component, result, extra) {
        cordova.exec(null, null, "Log", "wkLog", [uid, component, result, extra]);
    },

    //选择图片并裁剪
    takePhotoCrop: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "takePhotoCrop", []);
    },

    // 有些参数无法通过url传递给小应用，那么把这些参数穿个activity，再由小应用主动来取
    getExtraInfo: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "getExtraInfo", []);
    },

    // 小应用可以用这个接口来保存临时状态
    // 参数是json对象
    setState: function (state) {
        cordova.exec(null, null, "webPlatform", "setState", [state]);
    },

    // 获取临时状态，返回值是json对象
    getState: function (resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "getState", []);
    },

    /**
     * 设置事件的监听函数，原型为 function (event, data) {}
     * 监听函数的参数event为string, data为json对象
     **/
    addEventListener: function (listener) {
        this.eventListener = listener;
    },

    fireJavascriptEvent: function (event, data) {
        if (this.eventListener) {
            this.eventListener(event, data);
        }
    },

    /**
     * 设置共享事件的监听函数，原型为 function (event, data) {}
     * 共享事件可以在跨小应用进行消息发送
     **/
    registerSharedEventListener: function (listener) {
        this.sharedEventListener = listener;
        cordova.exec(null, null, "webPlatform", "registerSharedEventListener", []);
    },

    unregisterSharedEventListener: function () {
        this.sharedEventListener = null;
        cordova.exec(null, null, "webPlatform", "unregisterSharedEventListener", []);
    },

    sendSharedEvent: function (event, data) {
        cordova.exec(null, null, "webPlatform", "sendSharedEvent", [event, data]);
    },

    fireSharedEvent: function (event, data) {
        if (this.sharedEventListener) {
            this.sharedEventListener(event, data);
        }
    },

    /**
     * 显示系统toast
     * text: 要在toast中显示的字符串
     * duration: 0：短时间显示，1：长时间显示
     **/
    showToast: function (text, duration) {
        cordova.exec(null, null, "webPlatform", "showToast", [text, duration]);
    },

    /**
     * 从摇一摇启动用户详情页
     * userData: 用户信息json对象
     **/
    showUserDetailFromShake: function (userData) {
        cordova.exec(null, null, "Shake", "showUserDetail", [userData]);
    },

    /**
     * 摇一摇h5清除已读状态
     **/
    markShakeRequestAsRead: function () {
        cordova.exec(null, null, "Shake", "markShakeRequestAsRead", []);
    },

    /**
     * 摇一摇进入时获取打招呼的人
     **/
    getShakeGreetRequest: function () {
        cordova.exec(null, null, "Shake", "getShakeGreetRequest", []);
    },

    /**
     * 震动接口
     * milliseconds: 震动时长，单位毫秒
     **/
    vibrate: function (milliseconds) {
        cordova.exec(null, null, "Shake", "vibrate", [milliseconds]);
    },

    /**
     * 播放客户端assets目录下的声音文件
     * audio: 声音文件的路径，例如sound/shake_sound_male.mp3
     **/
    playAudioFromAssets: function (audio) {
        cordova.exec(null, null, "Shake", "playAudioFromAssets", [audio]);
    },

    /**
     * 跳转通讯录落地页
     **/
    jumpToPhoneContactActivity: function () {
        cordova.exec(null, null, "Contact", "jumpToPhoneContactActivity", []);
    },

    /**
     * 显示连信隐藏权政策
     * url: 隐藏权政策url
     **/
    showPrivacy: function (url) {
        cordova.exec(null, null, "Contact", "showPrivacy", [url]);
    },

    /**
     * 跳转好友圈
     * uid: uid
     **/
    onMoment: function (uid, coverUrl) {
        cordova.exec(null, null, "Contact", "onMoment", [uid, coverUrl]);
    },

    /**
     * 跳转聊天
     * uid: uid
     **/
    onChatter: function (uid) {
        cordova.exec(null, null, "Contact", "onChatter", [uid]);
    },

     /**
     * 跳转聊天
     * uid: uid
     * greetMsg: 招呼文案
     **/
    onChatterExt: function (uid, greetMsg) {
        cordova.exec(null, null, "Contact", "onChatterExt", [uid, greetMsg]);
    },

    /**
     * 跳转到群聊
     * uid: uid
     **/
    onGroupChat: function (groupId) {
        cordova.exec(null, null, "Contact", "onGroupChat", [groupId]);
    },

    /**
     * 获取个人信息
     * uid: uid
     **/
    getContactInfo: function (resultCallback, uid, exid) {
        console.log("getContactInfo");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "Contact", "getContactInfo", [uid, exid]);
    },

    /**
     * 获取相册列表
     * uid: uid
     **/
    getAlbumInfo: function (resultCallback, uid) {
        console.log("getAlbumInfo");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "Contact", "getAlbumInfo", [uid]);
    },

    /**
     * 获取模块未读
     **/
    getModuleUnRead: function (moduleName,resultCallback) {
        console.log("getModuleUnRead");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "getModuleUnRead", [moduleName]);
    },
    /**
     * 事件通知
     **/
    notifyEvent: function (args,resultCallback) {
        console.log("notifyEvent");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "notifyEvent", [args]);
    },


    /**
     * 设置模块未读
     **/
    setModuleUnRead: function (moduleName,count) {
        console.log("setUnreadCount");
        cordova.exec(null,null, "webPlatform", "setModuleUnRead", [moduleName,count]);
    },

    // 启动小应用
    launchWebModule: function (appId, query, options) {
        cordova.exec(null,null, "webPlatform", "launchWebModule", [appId, query, options]);
    },

    // 判断第三方应用apk是否已安装
    isAppInstalled: function (packageNameArray, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "isAppInstalled", [packageNameArray]);
    },

    // 打开第三方app
    startApp: function (packageName, from) {
        cordova.exec(null, null, "webPlatform", "startApp", [packageName, from]);
    },

    // 下载第三方app
    downloadApp: function (packageName, url) {
        cordova.exec(null, null, "webPlatform", "downloadApp", [packageName, url]);
    },

    // 暂停下载第三方app
    pauseDownloadApp: function (packageName) {
        cordova.exec(null, null, "webPlatform", "pauseDownloadApp", [packageName]);
    },

    // 恢复下载第三方app
    resumeDownloadApp: function (packageName) {
        cordova.exec(null, null, "webPlatform", "resumeDownloadApp", [packageName]);
    },

    // 安装第三方app
    installApp: function (packageName) {
        cordova.exec(null, null, "webPlatform", "installApp", [packageName]);
    },

    // 获取第三方app的状态列表
    getAppStateList: function(resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result)
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null)
            }
        }, "webPlatform", "getAppStateList", []);
    },

    // 用浏览器打开链接
    openUrlByBrowser: function (url, from, extra) {
        cordova.exec(null, null, "webPlatform", "openUrlByBrowser", [url, from, extra]);
    },

    //获取太极key，返回string值
    getTaiChiStringValue: function (key, defaultValue, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "webPlatform", "getTaiChiStringValue", [key, defaultValue]);
    },

    //获取太极key，返回boolean值
    getTaiChiBooleanValue: function (key, defaultValue, resultCallback) {
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result == 1);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(false);
            }
        }, "webPlatform", "getTaiChiBooleanValue", [key, defaultValue]);
    },

    overrideBackButton: function (enabled) {
        cordova.exec(null, null, "webPlatform", "overrideBackButton", [enabled]);
    },

    /**
     * 接受好友邀请
     * uid
     * rid
     * agreeSubType
     * sourceType
     **/
    acceptFriendRequest: function (resultCallback, uid, rid, md5Phone, agreeSubType, sourceType) {
        console.log("acceptFriendRequest");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "Contact", "acceptFriendRequest", [uid, rid, md5Phone, agreeSubType, sourceType]);
    },

    // 跳转到用户详情页面
    showContactDetails: function(userData) {
        cordova.exec(null, null, "Contact", "showContactDetails", [userData]);
    },


    // 跳转到用户详情页面，带from fromType，区分场景，强型落地页：30
    showContactDetailsExt: function(userData, sourceType, fromType) {
        cordova.exec(null, null, "Contact", "showContactDetailsExt", [userData, sourceType, fromType]);
    },

    // 跳转到用户详情页面，带from fromType，区分场景，强型落地页：16
    gotoPeopleNearby: function(fromType) {
        cordova.exec(null, null, "Contact", "gotoPeopleNearby", [fromType]);
    },

    // 获取增强型落地页列表
   getEnhancedContactList: function(resultCallback) {
        console.log("getEnhancedContactList");
        cordova.exec(function (result) {
            if (resultCallback != null) {
                resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "Contact", "getEnhancedContactList", []);
    },

    /**
     * 发起添加好友
     * userData  json obj 至少包含fromUid，requestType，sourceType
     * subType  int  增强型落地页 95
     * isReverse  boolean 是否是反转添加
     * info   String 申请问候语
     * remark  String 备注名
     **/
    addFriendRequest: function(resultCallback, userData, subType, isReverse, info, remark) {
         console.log("addFriendRequest");
         cordova.exec(function (result) {
             if (resultCallback != null) {
                 resultCallback(result);
             }
         }, function (error) {
             if (resultCallback != null) {
                 resultCallback(null);
             }
         }, "Contact", "doAddFriendRequest", [userData,  subType,  isReverse, info, remark]);
     },

     /**
      * 发起添加好友
      * userData   json obj 至少包含fromUid，requestType，sourceType
      * subType  int  增强型落地页 95
      * isReverse  boolean 是否是反转添加
      * info   String 申请问候语
      * remark  String 备注名
      **/
     applyFriendRequest: function(resultCallback, userData, subType, isReverse, info, remark) {
          console.log("applyFriendRequest");
          cordova.exec(function (result) {
              if (resultCallback != null) {
                  resultCallback(result);
              }
          }, function (error) {
              if (resultCallback != null) {
                  resultCallback(null);
              }
          }, "Contact", "doApplyFriendRequest", [userData,  subType,  isReverse, info, remark]);
      },

      //feed打卡成功
      markFeedSuccess: function(params, resultCallback) {
          	window.cordova.exec(function(result) {
          		if (resultCallback != null) {
          			resultCallback(result)
          		}
          	},
          	function(error) {
          		console.log(error)
          		if (resultCallback != null) {
          			resultCallback(null)
          		}
          	},
          	'General', 'markFeedSuccess', [params])
          },

          execAction: function(action, params, resultCallback) {
              window.cordova.exec(function(result) {
                  if (resultCallback != null) {
                      resultCallback(result)
                  }
              },function(error) {
                   console.log(error)
                   if (resultCallback != null) {
                       resultCallback(error)
                   }
               },'General', action, [params])
          },

     /**
     * 跳转到好友申请页面
     * userData  json obj
     * subType  int  增强型落地页 95
     **/
    gotoContactRequestSend: function(userData, subType) {
         console.log("gotoContactRequestSend");
         cordova.exec(null, null, "Contact", "gotoContactRequestSend", [userData,  subType]);
     },
       // 进入落地页列表
       enterEnhancedLandingPage: function() {
       console.log("enterEnhancedLandingPage");
           cordova.exec(null, null, "Contact", "enterEnhancedLandingPage", []);
        },

      // 退出落地页列表
       exitEnhancedLandingPage: function() {
       console.log("exitEnhancedLandingPage");
           cordova.exec(null, null, "Contact", "exitEnhancedLandingPage", []);
        },

    // 点击忽略按钮
    enhancedContactOnIgnore: function() {
        console.log("enhancedContactOnIgnore");
        cordova.exec(null, null, "Contact", "enhancedContactOnIgnore", []);
     },

    //打开增值一期支付页面
     showPaymentPage: function (url, resultCallback) {
      console.log("showPaymentPage");
      cordova.exec(function (result) {
        if (resultCallback != null) {
            resultCallback(result);
            }
        }, function (error) {
            if (resultCallback != null) {
                resultCallback(null);
            }
        }, "LxVip", "showPaymentPage", [url]);
     },

    //打开增值一期vip介绍页
     jumpToVIPIntroducePage: function (url, resultCallback) {
        console.log("jumpToVIPIntroducePage");
        cordova.exec(function (result) {
           if (resultCallback != null) {
               resultCallback(result);
              }
           }, function (error) {
               if (resultCallback != null) {
                   resultCallback(null);
               }
           }, "LxVip", "jumpToVIPIntroducePage", [url]);
     },

    //打开个人主页
     jumpToUserProfilePage: function (exid, fromType, sex, resultCallback) {
        console.log("jumpToUserProfilePage");
        cordova.exec(function (result) {
           if (resultCallback != null) {
               resultCallback(result);
              }
           }, function (error) {
               if (resultCallback != null) {
                   resultCallback(null);
               }
           }, "LxVip", "jumpToUserProfilePage", [exid, fromType, sex]);
     },

   //打开帖子动态详情页
      jumpToFeedDetailPage: function (exid, feedId, resultCallback) {
        console.log("jumpToUserProfilePage");
        cordova.exec(function (result) {
           if (resultCallback != null) {
               resultCallback(result);
              }
           }, function (error) {
              if (resultCallback != null) {
                  resultCallback(null);
              }
           }, "LxVip", "jumpToFeedDetailPage", [exid, feedId]);
      },

   //feed打卡成功
   markFeedSuccess: function(params, resultCallback) {
     window.cordova.exec(function(result) {
       if (resultCallback != null) {
           resultCallback(result)
           }
       }, function(error) {
          console.log(error)
          if (resultCallback != null) {
              resultCallback(null)
          }
       }, 'General', 'markFeedSuccess', [params])
   },

    //打招呼
    jumpToPrivateChatPage: function(params, resultCallback) {
         window.cordova.exec(function(result) {
           if (resultCallback != null) {
               resultCallback(result)
               }
           }, function(error) {
              console.log(error)
              if (resultCallback != null) {
                  resultCallback(null)
              }
           }, 'LxPrivateChat', 'jumpToPrivateChatPage', [params])
       },

};