zx.launchMiniProgram = function (appId) {
    cordova.exec(null, null, "MiniProgram", "launch", [appId]);
};